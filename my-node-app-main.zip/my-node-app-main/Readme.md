##### build Docker image called node-app. Execute from root

    docker build -t my_node_app .
    
##### push image to repo 

    docker tag my_node_app my_apps:node-1.0
